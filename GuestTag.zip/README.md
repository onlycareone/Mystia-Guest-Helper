# 稀客助手 GuestTag · 小白安装说明

> 《东方夜雀食堂》的一个小插件。营业时屏幕右侧会出现一块小木板，告诉你**这桌稀客喜欢什么、讨厌什么、这顿能掏多少钱、推荐你上哪几道菜和哪几种酒**。
> 版本 v1.2.0 ｜ 适用游戏 4.4.0e ｜ 需要 BepInEx 6（IL2CPP）

---

## 一、先看你是哪种情况

### 情况 A：你**从来没装过** BepInEx

那么压缩包里**所有东西都要**，包括 `BepInEx` 文件夹、`dotnet` 文件夹、`winhttp.dll`。

**怎么做：**
1. 完全退出游戏（Steam 里也确认没在跑）。
2. 在 Steam 里右键《东方夜雀食堂》→ 管理 → 浏览本地文件，打开游戏根目录
   （里面能看到 `Touhou Mystia Izakaya.exe`、`GameAssembly.dll`、`UnityPlayer.dll`）。
3. 把压缩包**解压**，把里面的全部文件/文件夹**直接拖进游戏根目录**，提示“是否合并/替换”就选**是**。
4. 装完你的游戏根目录应该长这样：

```
Touhou Mystia Izakaya\
├─ Touhou Mystia Izakaya.exe
├─ winhttp.dll              ← 压缩包带来的
├─ doorstop_config.ini      ← 压缩包带来的
├─ dotnet\                  ← 压缩包带来的
└─ BepInEx\
   ├─ core\
   ├─ unity-libs\
   ├─ config\
   └─ plugins\
      └─ GuestTag.dll       ← 插件本体
```

5. 启动游戏就能用。

### 情况 B：你**已经装过** BepInEx（游戏根目录里已经有 `BepInEx` 文件夹和 `winhttp.dll`）

那**只放一个文件**：

```
BepInEx\plugins\GuestTag.dll
```

也就是把压缩包里 `BepInEx\plugins\GuestTag.dll` 这一个文件，复制到你游戏目录里同名的位置。
**不要**再覆盖 `winhttp.dll`、`dotnet`、`BepInEx\core`，那些是你原来装好的，覆盖了反而可能把版本弄乱。

> 判断方法：打开游戏根目录，如果已经有 `BepInEx` 文件夹、并且 `BepInEx\core` 里有 `BepInEx.Core.dll`，就是情况 B。

---

## 二、启动游戏

正常从 Steam 启动就行，**默认的 DirectX 11 就能跑**，不需要任何启动参数。

**如果启动后几秒就闪退**（黑屏一下直接没了），按顺序做：

1. Steam 库 → 右键游戏 → 属性 → 已安装文件 → **验证游戏文件完整性**。
   2026-11-01 本机那次崩溃就是这么修好的：Steam 校验报「6 个文件缺失」、补回 67MB，根因是
   `Touhou Mystia Izakaya_Data/Resources/unity default resources` 这个文件丢了，
   Unity 加载内置错误着色器失败（日志里刷 `The resource Internal-ErrorShader.shader could not be loaded from the resource file!`）→ `UnityPlayer.dll` 崩溃。
2. 校验完还是崩，再在启动选项里填 `-force-vulkan` 兜底（换渲染后端，跟插件无关）。

---

## 三、怎么确认装好了

1. 进游戏、进「营业」之后，看**屏幕右侧**（默认位置）。
2. 只要有稀客进店，就会弹出一块暖色小木板，标题写着 `稀客助手 · N 位稀客`。
3. 想更确定，看日志文件：`BepInEx\LogOutput.log`，搜 `Mystia Guest Tag`，应该能看到：

```
Loading [Mystia Guest Tag 1.1.0]
[GuestTag] 已挂载稀客生成 Hook: ...
[GuestTag] 已挂载 SceneManager.OnGUI 绘制点
[GuestTag] 厨具：煮锅、烤架
Mystia Guest Tag 已就绪：...
```

有一行 `已就绪` 就说明工作正常。

---

## 四、面板怎么看、怎么点

木板上每位稀客分几行：

```
稀客助手 · 3 位稀客
显示 - 3 +     菜品 - 4 +     酒水 - 4 +
策略: 高价优先 ▸ 点击切换

雾雨魔理沙  Marisa   预算 ¥4834
喜好  和风 · 菌类 · 传说 · 重油 · 灼热
厌恶  猎奇
[高价优先推荐] 大奢宴 (¥105/x36)、豚骨拉面 (¥60/x12)
[高价优先酒水] 水獭祭 (¥130/x2)、天狗踊 (¥70/x5)
```

- **显示 / 菜品 / 酒水**：点 `-` `+` 调数量，点完**当场生效并写进配置**，不用重启。
- **策略**：点那一行会在三种之间循环——
  - `低价优先`：挑预算内偏便宜但不亏的菜（清库存）
  - `高价优先`：挑预算内最贵的菜（赚一笔）
  - `少料易做`：优先食材种类少的菜
  - 鼠标点一下那一行就行。
- **滚轮**：稀客比「显示数量」多的时候，鼠标放在木板上滚，循环翻页；标题会写 `已显示 1-2/3 位`。
- **拖动**：按住顶部标题行可以拖走，松开自动记住位置。
- **F10**：整个面板隐藏/显示。
- **`/x36`**：这个菜按你背包食材还能做 36 份（酒水就是还剩 36 瓶）。

面板里所有菜都经过四道筛选：**你今晚的菜单 + 你真解锁了的菜 + 背包食材够做 + 台上有对应厨具**，所以不会出现「看得见做不出」的菜。

---

## 五、配置文件（想改再看，不改也能用）

装了之后会生成：`BepInEx\config\cc.mystia.guesttag.cfg`

常改的几个：

| 配置项 | 默认 | 作用 |
| --- | --- | --- |
| `[Display] MaxGuestsToDisplay` | 3 | 面板最多同时列几位稀客 |
| `[Display] MaxRecipesPerGuest` | 3 | 每位稀客最多几条菜 |
| `[Display] MaxDrinksPerGuest` | 3 | 每位稀客最多几种酒 |
| `[Display] Strategy` | PriceLow | 默认策略：PriceLow / PriceHigh / FewIngredients |
| `[UI] FontSize` | 16 | 字号，嫌小改 18，嫌大改 14 |
| `[UI] UI_X` / `[UI] UI_Y` | -1 | 面板位置；拖动会自动写这里，改回 `-1` 恢复自动 |
| `[Cookware] Override` | 空 | 读不到厨具时手填，例如 `煮锅 = 2; 油锅 = 1` |

改完保存，**下次启动生效**（面板上的 ± 按钮例外，那个立刻生效）。

---

## 六、常见问题

**面板不出现？**
营业中才有稀客，白天不显示。确认你已经进入「营业」、并且确实有稀客进店（普通客人不算）。
再看 `BepInEx\LogOutput.log` 有没有 `已就绪`。

**推荐显示「无匹配」？**
这一晚的菜单里没有符合她口味、又不超预算、又做得出来的菜。换几道菜进今日菜单，或者等她换一位。

**颜色里那个 `[新稀客] 数据未收录`？**
游戏里这个新角色的数据读不出来（一般是新 DLC 刚出）。插件不会崩，只是这行没有推荐。

**鼠标变成 Windows 白箭头？**
切一下窗口（Alt+Tab 出去再回来）就恢复；这是游戏本身切换光标状态导致的，插件已经不强行改光标了。

**想卸载？**
删掉 `BepInEx\plugins\GuestTag.dll` 就行，其它都不用动。
如果当初是整套装的 BepInEx，想彻底还原就把 `winhttp.dll` 删掉（或改名），游戏就回到原版。

---

## 七、它到底读了游戏里的什么（给好奇的人）

- 稀客：`SpecialGuestsController.SpecialGuest` 的 `stringId`、名字、`LikeFoodTag`（喜好）、`HateFoodTagOriginal`（厌恶）
- 喜好权重：`SpecialGuest.likeFoodTag` / `likeBevTag` 的 `WeightedTag`（`tagId` + `weight`）——推荐是按这个**权重得分**排的，不是拍脑袋
- 预算：`GuestGroupController.MaxFundCarry`
- 菜单/解锁：`IzakayaConfigure.DailyRecipes`、`RunTimeStorage.Recipes`
- 食材/备菜：`RunTimeStorage.Ingredients`、`RunTimeStorage.Foods`
- 酒水库存：`RunTimeStorage.Beverages`；酒水单：`IzakayaConfigure.DailyBeverages`
- 厨具：场景里 `CookController.Cooker.Type`

全部是**运行时读取**，代码里**没有任何硬编码的稀客名单或菜谱表**（v1.2.0 起连「查表名单」也删掉了）；
以后出新 DLC、新稀客、新菜，只要解锁并写进今日菜单就会自动出现在推荐里。

### 推荐是怎么算的（v1.2.0）

1. 池子：`今日菜单` → 没有就取 `已解锁菜谱`，再过「背包食材够不够做」和「台上有没有这台厨具」。
2. 打分：`Σ(命中喜好标签的 weight) × 10 + 命中标签数`，带任何「厌恶」标签的菜直接剔除。
3. 排序：再按你选的策略（低价优先 / 高价优先 / 少料易做）排，最后按预算截断。
4. 日志里能看到打分：`稀客 [Marisa] 权重打分前 3：豚骨拉面 权重7+1命中 ¥60 / …`（把 `BepInEx.cfg` 的日志级别调到 Debug 才显示）。
